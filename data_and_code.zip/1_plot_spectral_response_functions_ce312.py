import numpy as np
import matplotlib.pyplot as plt


def batch_split_numpy(data, delimiter = ' ' + '\t'):
    ds = np.array([item.strip().split(delimiter) for item in data])
    print(ds.shape)

    x = ds[:, 0].astype(float)
    y = ds[:, 1].astype(float)
    return x, y


def read_file():
    arr = []
    with open('data/CE312_filter_function.flt', 'r') as file:
        data = file.readlines()
        for i, line in enumerate(data):
            if line[:6] == 'Center':
                print(i, line)
                arr.append(i)

        plt.figure()

        for ai, ar in enumerate(arr):
            if ai < 5:
                print(ar+1, arr[ai+1])
                d = data[ar+1 : arr[ai + 1]]
                x, y = batch_split_numpy(d)
                plt.plot(x, y, label = 'Channel '+ str(ai+1))
            else:
                print(ar+1)
                d = data[ar+1: ]
                x, y = batch_split_numpy(d)
                plt.plot(x, y, label = 'Channel '+ str(ai+1))
        plt.xlabel(r'Wavelength ($\mu m$)')
        plt.ylabel('Response')
        plt.legend()
        plt.show()







if __name__ == '__main__':
    read_file()