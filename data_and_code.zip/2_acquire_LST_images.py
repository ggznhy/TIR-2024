import cv2
import numpy as np
import os

# 定义线性变换函数
def apply_linear_transform(image, a, b):
    # 应用线性变换 y = a * x + b
    transformed_image = a * image + b
    transformed_image = np.clip(transformed_image, 0, 255)  # 限制在 uint16 范围内
    # 转换为uint8类型
    transformed_image = transformed_image.astype(np.uint8)
    return transformed_image

# 读取图像并应用线性变换
def process_images(image_folder, output_folder, linear_params):
    # 确保输出文件夹存在
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 获取图像文件列表
    image_files = [f for f in os.listdir(image_folder) if f.endswith(('.jpg', '.JPG'))]
    image_files.sort()  # 确保按顺序处理

    # 检查图像数量是否匹配
    if len(image_files) != len(linear_params):
        raise ValueError("图像数量与线性参数数量不匹配")

    # 处理每张图像
    for i, image_file in enumerate(image_files):
        # 读取图像
        image_path = os.path.join(image_folder, image_file)
        image = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)

        # 获取线性参数
        a, b = linear_params[i]

        # 应用线性变换
        transformed_image = apply_linear_transform(image, a, b)

        # 保存处理后的图像
        output_path = os.path.join(output_folder, f"LST_{image_file}")
        cv2.imwrite(output_path, transformed_image)
        print(f"已保存: {output_path}")

# 示例线性参数 (a, b) 列表，假设有17组参数
linear_params = [
    (0.024313725, 5.8),  # 第一张图像的参数
    (0.024313725, 11.3),  # 第二张图像的参数
    (0.045098039, 1.6),
    (0.024313725, 2.3),
    (0.024313725, 4.9),  # 5
    (0.028627451, 0.1),
    (0.221568627, -43.1),
    (0.024313725, 2.1),  #
    (0.030588235, 3.8),
    (0.041568627, 1.3),
    (0.029019608, 5.9),
    (0.064313725, 4.5),
    (0.056470588, 6.2),
    (0.04745098, 5),
    (0.024313725, -2.2),
    (0.024313725, -7.5),
    (0.197647059, -41)  # 17
]


if __name__ == '__main__':
    # 图像文件夹和输出文件夹路径
    image_folder = 'data/images'
    output_folder = 'data/img_output'

    # 处理图像
    process_images(image_folder, output_folder, linear_params)