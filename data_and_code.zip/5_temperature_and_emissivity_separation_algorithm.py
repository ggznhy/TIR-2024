import numpy as np
from scipy.optimize import minimize


# Planck's Law
def planck(wavelength, t):
    """
    Planck's law computation
    :param wavelength: 波长 (µm)
    :param t: 温度 (K)
    :return: 辐射亮度 (W/m^2/sr/µm)
    """
    h = 6.626e-34  # 普朗克常数 (J·s)
    c = 2.998e8    # 光速 (m/s)
    k = 1.381e-23  # 玻尔兹曼常数 (J/K)
    return (2 * h * c**2) / (wavelength**5 * (np.exp((h * c) / (wavelength * k * t)) - 1))

# 目标函数：最小化观测值与模型预测值之间的差异
def objective_function(params, wavelengths, L_obs):
    """
    目标函数：计算观测值与模型预测值之间的差异
    :param params: 参数列表 [T, epsilon_1, epsilon_2, ..., epsilon_n]
    :param wavelengths: 波长列表 (µm)
    :param L_obs: 观测的辐射亮度列表 (W/m^2/sr/µm)
    :return: 差异的平方和
    """
    T = params[0]  # 温度
    epsilons = params[1:]  # 发射率
    L_pred = epsilons * planck(wavelengths, T)  # 模型预测的辐射亮度
    return np.sum((L_obs - L_pred) ** 2)  # 差异的平方和

# TES算法
def TES(wavelengths, L_obs, T_initial, epsilon_initial):
    """
    TES算法：分离地表温度和发射率
    :param wavelengths: 波长列表 (µm)
    :param L_obs: 观测的辐射亮度列表 (W/m^2/sr/µm)
    :param T_initial: 初始温度估计 (K)
    :param epsilon_initial: 初始发射率估计列表
    :return: 反演的温度和发射率
    """
    # 初始参数
    initial_params = np.concatenate(([T_initial], epsilon_initial))

    # 优化
    result = minimize(objective_function, initial_params, args=(wavelengths, L_obs),
                      bounds=[(200, 400)] + [(0.8, 1.0)] * len(wavelengths))

    # 提取结果
    T_retrieved = result.x[0]
    epsilons_retrieved = result.x[1:]
    return T_retrieved, epsilons_retrieved





if __name__ == "__main__":
    # # 示例数据
    # wavelengths = np.array([11.3, 10.6, 9.1, 8.7, 8.3])  # 波长 (µm)
    # L_obs = np.array([100.0, 105.0, 110.0, 1, 1])  # 观测的辐射亮度 (W/m^2/sr/µm)
    # T_initial = 300.0  # 初始温度估计 (K)
    # epsilon_initial = np.array([0.99, 0.99, 0.99, 0.99, 0.99])  # 初始发射率估计
    #
    # # 运行TES算法
    # T_retrieved, epsilons_retrieved = TES(wavelengths, L_obs, T_initial, epsilon_initial)
    #
    # # 输出结果
    # print(f"反演的地表温度: {T_retrieved:.2f} K")
    # print(f"反演的发射率: {epsilons_retrieved}")

    print(planck(11.3, 14.05+273.15))