import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

with open('data/CR300Series16562_Data20240816.dat') as file:
    lines = file.readlines()
    lines_data = lines[4: ]
    y = []
    for l in lines_data:
        print(l.split(','))
        y.append(l.split(',')[2:4])
    y = np.array(y)
    # print(y)

    plt.figure()
    plt.plot(range(len(y[:, 0])), np.float32(y[:, 0]), label='up')
    plt.plot(range(len(y[:, 0])), np.float32(y[:, 1]), label='down')
    plt.ylabel('Temperature ($ ℃ $)')
    plt.xlabel('Time ($min$)')
    plt.legend()
    plt.show()